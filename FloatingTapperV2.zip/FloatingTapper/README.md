# Floating Tapper

A floating TAP button that sends a tap to a spot you choose anywhere on the screen.

## Usage
1. Install the APK, open the app and turn on the "Floating Tapper" accessibility service.
2. Tap "Show Floating Button".
3. Long-press the TAP button, choose "Set Position", drag the red crosshair to the spot, then tap the button (LOCK) to lock it.
4. Tap the TAP button to click at that spot.
5. Long-press the button any time for the menu: Auto Click, Interval, Double Tap, Swipe Up/Down/Left/Right, Back, Home, Recents, Notifications, Screenshot, Hide/Show Crosshair, Button Size, Close.

## Notes
- Android 13 and newer: if the service is greyed out, open Settings > Apps > Floating Tapper > menu > Allow restricted settings.
- Some banking and security apps block taps injected by accessibility services.
