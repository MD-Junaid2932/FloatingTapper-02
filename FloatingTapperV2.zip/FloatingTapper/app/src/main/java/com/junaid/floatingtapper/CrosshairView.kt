package com.junaid.floatingtapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.min

/** টার্গেট পয়েন্ট চিহ্নিত করার ক্রসহেয়ার। কেন্দ্রবিন্দুই ক্লিকের জায়গা। */
class CrosshairView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.BLACK
        strokeWidth = 5f * density
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    /** true হলে সেট মোড (লাল), নয়তো লক করা (নীল)। */
    var active: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 4f * density
        val color = if (active) 0xFFFF1744.toInt() else 0xFF2979FF.toInt()
        line.color = color
        dot.color = color

        // কালো বর্ডার (যেকোনো ব্যাকগ্রাউন্ডে দৃশ্যমান রাখতে)
        canvas.drawCircle(cx, cy, r, outline)
        canvas.drawLine(cx - r, cy, cx + r, cy, outline)
        canvas.drawLine(cx, cy - r, cx, cy + r, outline)

        // রঙিন অংশ
        canvas.drawCircle(cx, cy, r, line)
        canvas.drawLine(cx - r, cy, cx + r, cy, line)
        canvas.drawLine(cx, cy - r, cx, cy + r, line)
        canvas.drawCircle(cx, cy, 3f * density, dot)
    }
}
