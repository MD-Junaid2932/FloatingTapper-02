package com.junaid.floatingtapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** Full-screen overlay where the user drags a box over an area of the screen. */
class RegionSelectView(
    context: Context,
    private val title: String,
    private val accent: Int
) : View(context) {

    /** Called once: with the chosen rectangle (view coordinates), or null if cancelled. */
    var onDone: ((Rect?) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private var sx = 0f
    private var sy = 0f
    private var ex = 0f
    private var ey = 0f
    private var drawing = false
    private var finished = false
    private var hint: String? = null
    private val cancelRect = RectF()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = accent
        alpha = 70
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = accent
        strokeWidth = 3f * d
    }
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xDD000000.toInt()
    }
    private val cancelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFFD32F2F.toInt()
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f * d
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0x55000000)
        if (drawing) {
            val r = RectF(min(sx, ex), min(sy, ey), max(sx, ex), max(sy, ey))
            canvas.drawRect(r, fill)
            canvas.drawRect(r, stroke)
        }
        val cx = width / 2f
        val titleBox = RectF(cx - 150f * d, 56f * d, cx + 150f * d, 96f * d)
        canvas.drawRoundRect(titleBox, 12f * d, 12f * d, pill)
        canvas.drawText(hint ?: title, cx, titleBox.centerY() + textPaint.textSize / 3f, textPaint)

        cancelRect.set(cx - 60f * d, 106f * d, cx + 60f * d, 144f * d)
        canvas.drawRoundRect(cancelRect, 12f * d, 12f * d, cancelPaint)
        canvas.drawText("Cancel", cx, cancelRect.centerY() + textPaint.textSize / 3f, textPaint)
    }

    private fun finish(r: Rect?) {
        if (finished) return
        finished = true
        onDone?.invoke(r)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (cancelRect.contains(e.x, e.y)) {
                    finish(null)
                    return true
                }
                sx = e.x; sy = e.y; ex = e.x; ey = e.y
                drawing = true
                hint = null
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                ex = e.x; ey = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                ex = e.x; ey = e.y
                if (!drawing) return true
                val r = Rect(
                    min(sx, ex).toInt(), min(sy, ey).toInt(),
                    max(sx, ex).toInt(), max(sy, ey).toInt()
                )
                if (r.width() < 30 * d || r.height() < 20 * d) {
                    drawing = false
                    hint = "Too small, drag a bigger box"
                    invalidate()
                } else {
                    finish(r)
                }
            }
        }
        return true
    }
}

/** Shows the saved question / options areas for a moment. Not touchable. */
class AreasPreviewView(
    context: Context,
    private val question: Rect?,
    private val options: Rect?
) : View(context) {

    private val d = resources.displayMetrics.density

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * d
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * d
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun drawArea(canvas: Canvas, r: Rect, dx: Int, dy: Int, color: Int, name: String) {
        val rf = RectF(
            (r.left - dx).toFloat(), (r.top - dy).toFloat(),
            (r.right - dx).toFloat(), (r.bottom - dy).toFloat()
        )
        fill.color = color
        fill.alpha = 60
        stroke.color = color
        canvas.drawRect(rf, fill)
        canvas.drawRect(rf, stroke)
        val tagW = label.measureText(name) + 12f * d
        val tag = RectF(rf.left, rf.top - 22f * d, rf.left + tagW, rf.top)
        fill.color = color
        fill.alpha = 255
        canvas.drawRect(tag, fill)
        canvas.drawText(name, tag.left + 6f * d, tag.bottom - 6f * d, label)
    }

    override fun onDraw(canvas: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        question?.let { drawArea(canvas, it, loc[0], loc[1], 0xFF2979FF.toInt(), "QUESTION") }
        options?.let { drawArea(canvas, it, loc[0], loc[1], 0xFF00C853.toInt(), "OPTIONS") }
    }
}
