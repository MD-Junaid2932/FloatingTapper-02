package com.junaid.floatingtapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import kotlin.math.hypot
import kotlin.math.min

/**
 * Accessibility service that shows a floating TAP button and a crosshair.
 * Tapping the button sends a tap gesture to the crosshair centre.
 * Long-pressing the button opens a multi-function menu.
 *
 * Overlays use TYPE_ACCESSIBILITY_OVERLAY, so no "draw over other apps" permission is needed.
 */
class TapAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TapAccessibilityService? = null
            private set

        private const val BLUE = 0xE61E88E5.toInt()
        private const val ORANGE = 0xE6FF6D00.toInt()
        private const val RED = 0xE6D32F2F.toInt()
        private const val GREEN = 0xE62E7D32.toInt()
    }

    private class MenuItem(
        val label: () -> String,
        val closes: Boolean,
        val action: () -> Unit
    )

    private val intervals = longArrayOf(100, 250, 500, 1000, 2000)
    private val sizesDp = intArrayOf(44, 56, 72)
    private val sizeLabels = arrayOf("S", "M", "L")

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("tapper", MODE_PRIVATE) }

    private var mainView: TextView? = null
    private var markerView: CrosshairView? = null
    private var menuView: View? = null
    private val menuButtons = mutableListOf<Pair<TextView, MenuItem>>()
    private lateinit var mainLp: WindowManager.LayoutParams
    private lateinit var markerLp: WindowManager.LayoutParams

    private var setMode = false
    private var autoClicking = false
    private var markerHidden = false
    private var intervalIndex = 2
    private var sizeIndex = 1

    // Auto Solve state
    private var solving = false
    @Volatile private var busy = false
    private var lastSig = ""
    private var lastSigTime = 0L
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val screenshotExecutor by lazy { Executors.newSingleThreadExecutor() }

    // main button touch state
    private var mDownX = 0f
    private var mDownY = 0f
    private var mStartX = 0
    private var mStartY = 0
    private var mDragging = false
    private var mLongFired = false

    // marker touch state
    private var kDownX = 0f
    private var kDownY = 0f
    private var kStartX = 0
    private var kStartY = 0

    val isShowing: Boolean get() = mainView != null

    private val longPressRunnable = Runnable {
        if (!mDragging) {
            mLongFired = true
            mainView?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            openMenu()
        }
    }

    private val autoRunnable = object : Runnable {
        override fun run() {
            if (!autoClicking) return
            tapAtMarker()
            handler.postDelayed(this, intervals[intervalIndex])
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        intervalIndex = prefs.getInt("interval", 2).coerceIn(0, intervals.lastIndex)
        sizeIndex = prefs.getInt("size", 1).coerceIn(0, sizesDp.lastIndex)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideOverlay()
        instance = null
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------ overlay

    fun showOverlay() {
        if (mainView != null) return
        val dm = resources.displayMetrics
        val mainSize = dp(sizesDp[sizeIndex])
        val markSize = dp(44)
        val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        // Crosshair: NOT_TOUCHABLE while locked so taps are never swallowed
        markerLp = WindowManager.LayoutParams(
            markSize, markSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("mx", dm.widthPixels / 2 - markSize / 2)
            y = prefs.getInt("my", dm.heightPixels / 2 - markSize / 2)
        }
        val marker = CrosshairView(this).apply {
            alpha = 0.5f
            setOnTouchListener { v, e -> onMarkerTouch(v, e) }
        }

        // Click button
        mainLp = WindowManager.LayoutParams(
            mainSize, mainSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("bx", dm.widthPixels - mainSize - dp(16))
            y = prefs.getInt("by", dm.heightPixels / 2)
        }
        val main = TextView(this).apply {
            text = "TAP"
            setTextColor(Color.WHITE)
            textSize = textSizeFor(sizeIndex)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = circle(BLUE)
            setOnTouchListener { v, e -> onMainTouch(v, e) }
        }

        wm.addView(marker, markerLp)
        wm.addView(main, mainLp)
        markerView = marker
        mainView = main
        setMode = false
        autoClicking = false
        markerHidden = false
    }

    fun hideOverlay() {
        handler.removeCallbacks(longPressRunnable)
        handler.removeCallbacks(autoRunnable)
        autoClicking = false
        solving = false
        handler.removeCallbacks(solveRunnable)
        closeMenu()
        try { markerView?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { mainView?.let { wm.removeView(it) } } catch (_: Exception) {}
        markerView = null
        mainView = null
        setMode = false
        markerHidden = false
    }

    private fun textSizeFor(index: Int): Float = when (index) {
        0 -> 11f
        1 -> 13f
        else -> 15f
    }

    private fun circle(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(dp(2), Color.WHITE)
    }

    private fun refreshMainLook() {
        val main = mainView ?: return
        when {
            solving -> {
                main.text = "STOP"
                main.background = circle(GREEN)
            }
            autoClicking -> {
                main.text = "STOP"
                main.background = circle(RED)
            }
            setMode -> {
                main.text = "LOCK"
                main.background = circle(ORANGE)
            }
            else -> {
                main.text = "TAP"
                main.background = circle(BLUE)
            }
        }
    }

    // ------------------------------------------------------------ touch

    private fun onMainTouch(v: View, e: MotionEvent): Boolean {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mDownX = e.rawX; mDownY = e.rawY
                mStartX = mainLp.x; mStartY = mainLp.y
                mDragging = false
                mLongFired = false
                v.alpha = 0.7f
                handler.postDelayed(longPressRunnable, 600)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - mDownX
                val dy = e.rawY - mDownY
                if (!mDragging && hypot(dx, dy) > slop) {
                    mDragging = true
                    handler.removeCallbacks(longPressRunnable)
                }
                if (mDragging) {
                    mainLp.x = mStartX + dx.toInt()
                    mainLp.y = mStartY + dy.toInt()
                    wm.updateViewLayout(v, mainLp)
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                v.alpha = 1f
                when {
                    mDragging -> savePositions()
                    !mLongFired -> onMainClick()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                v.alpha = 1f
            }
        }
        return true
    }

    private fun onMarkerTouch(v: View, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                kDownX = e.rawX; kDownY = e.rawY
                kStartX = markerLp.x; kStartY = markerLp.y
            }
            MotionEvent.ACTION_MOVE -> {
                markerLp.x = kStartX + (e.rawX - kDownX).toInt()
                markerLp.y = kStartY + (e.rawY - kDownY).toInt()
                wm.updateViewLayout(v, markerLp)
            }
            MotionEvent.ACTION_UP -> savePositions()
        }
        return true
    }

    private fun savePositions() {
        prefs.edit()
            .putInt("bx", mainLp.x).putInt("by", mainLp.y)
            .putInt("mx", markerLp.x).putInt("my", markerLp.y)
            .apply()
    }

    private fun onMainClick() {
        when {
            solving -> stopSolving(true)
            autoClicking -> stopAutoClick()
            setMode -> toggleSetMode() // locks the position
            else -> tapAtMarker()
        }
    }

    // ------------------------------------------------------------ menu

    private fun menuItems(): List<MenuItem> = listOf(
        MenuItem({ if (setMode) "Lock Position" else "Set Position" }, true) { toggleSetMode() },
        MenuItem({ if (autoClicking) "Auto Click: ON" else "Auto Click: OFF" }, true) { toggleAutoClick() },
        MenuItem({ if (solving) "Auto Solve: ON" else "Auto Solve: OFF" }, true) { toggleSolving() },
        MenuItem({ "Interval: ${intervals[intervalIndex]} ms" }, false) { cycleInterval() },
        MenuItem({ "Double Tap" }, true) { doubleTapAtMarker() },
        MenuItem({ "Swipe Up" }, true) { swipe(0f, -1f) },
        MenuItem({ "Swipe Down" }, true) { swipe(0f, 1f) },
        MenuItem({ "Swipe Left" }, true) { swipe(-1f, 0f) },
        MenuItem({ "Swipe Right" }, true) { swipe(1f, 0f) },
        MenuItem({ "Back" }, true) { performGlobalAction(GLOBAL_ACTION_BACK) },
        MenuItem({ "Home" }, true) { performGlobalAction(GLOBAL_ACTION_HOME) },
        MenuItem({ "Recents" }, true) { performGlobalAction(GLOBAL_ACTION_RECENTS) },
        MenuItem({ "Notifications" }, true) { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) },
        MenuItem({ "Screenshot" }, true) { takeScreenshotAction() },
        MenuItem({ if (markerHidden) "Show Crosshair" else "Hide Crosshair" }, false) { toggleMarkerVisibility() },
        MenuItem({ "Button Size: ${sizeLabels[sizeIndex]}" }, false) { cycleSize() },
        MenuItem({ "Close Floating Button" }, true) { hideOverlay() }
    )

    private fun openMenu() {
        if (menuView != null) {
            closeMenu()
            return
        }
        val dm = resources.displayMetrics

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(0xF2212121.toInt())
            }
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        panel.addView(TextView(this).apply {
            text = "Floating Tapper"
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        })

        menuButtons.clear()
        val items = menuItems()
        var i = 0
        while (i < items.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in i until min(i + 2, items.size)) {
                val item = items[j]
                val tv = TextView(this).apply {
                    text = item.label()
                    setTextColor(Color.WHITE)
                    textSize = 12f
                    gravity = Gravity.CENTER
                    maxLines = 2
                    background = GradientDrawable().apply {
                        cornerRadius = dp(10).toFloat()
                        setColor(0xFF424242.toInt())
                    }
                    setPadding(dp(6), dp(6), dp(6), dp(6))
                    setOnClickListener { onMenuItem(item) }
                }
                val lp = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                }
                row.addView(tv, lp)
                menuButtons.add(Pair(tv, item))
            }
            panel.addView(row)
            i += 2
        }

        val root = ScrollView(this).apply {
            addView(panel)
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) {
                    closeMenu()
                    true
                } else {
                    false
                }
            }
        }

        val lp = WindowManager.LayoutParams(
            min(dp(320), (dm.widthPixels * 0.92f).toInt()),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        wm.addView(root, lp)
        menuView = root
    }

    private fun closeMenu() {
        try { menuView?.let { wm.removeView(it) } } catch (_: Exception) {}
        menuView = null
        menuButtons.clear()
    }

    private fun onMenuItem(item: MenuItem) {
        if (item.closes) {
            // Close first (and wait a moment) so the menu never blocks gestures or screenshots
            closeMenu()
            handler.postDelayed({ item.action() }, 250)
        } else {
            item.action()
            menuButtons.forEach { (tv, mi) -> tv.text = mi.label() }
        }
    }

    // ------------------------------------------------------------ modes

    private fun toggleSetMode() {
        val marker = markerView ?: return
        if (mainView == null) return
        if (autoClicking) stopAutoClick()
        if (solving) stopSolving(false)
        setMode = !setMode
        if (setMode) {
            markerHidden = false
            marker.visibility = View.VISIBLE
            markerLp.flags = markerLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            marker.alpha = 1f
            toast("Set mode: drag the crosshair to the spot, then tap the button to lock")
        } else {
            markerLp.flags = markerLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            marker.alpha = 0.5f
            savePositions()
            toast("Position locked. Tap the button to click there")
        }
        marker.active = setMode
        wm.updateViewLayout(marker, markerLp)
        refreshMainLook()
    }

    private fun toggleAutoClick() {
        if (autoClicking) stopAutoClick() else startAutoClick()
    }

    private fun startAutoClick() {
        if (setMode) {
            toast("Lock the position first")
            return
        }
        if (solving) stopSolving(false)
        autoClicking = true
        refreshMainLook()
        toast("Auto click started. Tap the button to stop")
        handler.post(autoRunnable)
    }

    private fun stopAutoClick() {
        autoClicking = false
        handler.removeCallbacks(autoRunnable)
        refreshMainLook()
        toast("Auto click stopped")
    }

    // ------------------------------------------------------------ auto solve

    private val solveRunnable = object : Runnable {
        override fun run() {
            if (!solving) return
            if (!busy && menuView == null) captureAndRecognize()
            handler.postDelayed(this, 900)
        }
    }

    private fun toggleSolving() {
        if (solving) stopSolving(true) else startSolving()
    }

    private fun startSolving() {
        if (Build.VERSION.SDK_INT < 30) {
            toast("Auto Solve needs Android 11 or newer")
            return
        }
        if (mainView == null) return
        if (setMode) {
            toast("Lock the position first")
            return
        }
        if (autoClicking) stopAutoClick()
        solving = true
        lastSig = ""
        refreshMainLook()
        toast("Auto Solve started. Tap the button to stop")
        handler.post(solveRunnable)
    }

    private fun stopSolving(announce: Boolean) {
        solving = false
        handler.removeCallbacks(solveRunnable)
        refreshMainLook()
        if (announce) toast("Auto Solve stopped")
    }

    private fun captureAndRecognize() {
        if (Build.VERSION.SDK_INT < 30) return
        busy = true
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                screenshotExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        var bmp: Bitmap? = null
                        try {
                            val hw = result.hardwareBuffer
                            try {
                                val wrapped = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                                bmp = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                                wrapped?.recycle()
                            } finally {
                                hw.close()
                            }
                        } catch (e: Exception) {
                            bmp = null
                        }
                        val image = bmp
                        if (image == null) {
                            busy = false
                            return
                        }
                        recognizer.process(InputImage.fromBitmap(image, 0))
                            .addOnSuccessListener { text -> onRecognized(text) }
                            .addOnCompleteListener {
                                busy = false
                                image.recycle()
                            }
                    }

                    override fun onFailure(errorCode: Int) {
                        busy = false
                    }
                }
            )
        } catch (e: Exception) {
            busy = false
        }
    }

    private fun onRecognized(text: Text) {
        if (!solving) return
        val lines = ArrayList<MathSolver.Line>()
        for (block in text.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                lines.add(MathSolver.Line(line.text, box.exactCenterX(), box.exactCenterY()))
            }
        }
        val target = MathSolver.find(lines, text.text)
        if (target == null) {
            lastSig = "" // question is gone, be ready for the next one
            return
        }
        val sig = "${target.question}=${target.answer}"
        val now = SystemClock.uptimeMillis()
        if (sig == lastSig && now - lastSigTime < 3000) return
        lastSig = sig
        lastSigTime = now
        tapAt(target.x, target.y)
    }

    private fun cycleInterval() {
        intervalIndex = (intervalIndex + 1) % intervals.size
        prefs.edit().putInt("interval", intervalIndex).apply()
    }

    private fun cycleSize() {
        val main = mainView ?: return
        sizeIndex = (sizeIndex + 1) % sizesDp.size
        prefs.edit().putInt("size", sizeIndex).apply()
        val s = dp(sizesDp[sizeIndex])
        mainLp.width = s
        mainLp.height = s
        main.textSize = textSizeFor(sizeIndex)
        wm.updateViewLayout(main, mainLp)
    }

    private fun toggleMarkerVisibility() {
        if (setMode) {
            toast("Not available while setting the position")
            return
        }
        markerHidden = !markerHidden
        markerView?.visibility = if (markerHidden) View.INVISIBLE else View.VISIBLE
    }

    private fun takeScreenshotAction() {
        if (Build.VERSION.SDK_INT >= 28) {
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        } else {
            toast("Screenshot needs Android 9 or newer")
        }
    }

    // ------------------------------------------------------------ gestures

    private fun markerCenter(): Pair<Float, Float>? {
        val marker = markerView ?: return null
        val loc = IntArray(2)
        marker.getLocationOnScreen(loc)
        return Pair(loc[0] + marker.width / 2f, loc[1] + marker.height / 2f)
    }

    private fun dispatch(vararg strokes: GestureDescription.StrokeDescription) {
        val builder = GestureDescription.Builder()
        for (s in strokes) builder.addStroke(s)
        dispatchGesture(builder.build(), null, null)
    }

    private fun tapAtMarker() {
        val (x, y) = markerCenter() ?: return
        tapAt(x, y)
    }

    private fun tapAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        dispatch(GestureDescription.StrokeDescription(path, 0, 50))
    }

    private fun doubleTapAtMarker() {
        val (x, y) = markerCenter() ?: return
        val p1 = Path().apply { moveTo(x, y) }
        val p2 = Path().apply { moveTo(x, y) }
        dispatch(
            GestureDescription.StrokeDescription(p1, 0, 40),
            GestureDescription.StrokeDescription(p2, 120, 40)
        )
    }

    private fun swipe(dirX: Float, dirY: Float) {
        val (x, y) = markerCenter() ?: return
        val dm = resources.displayMetrics
        val dist = if (dirX != 0f) 0.35f * dm.widthPixels else 0.35f * dm.heightPixels
        val endX = (x + dirX * dist).coerceIn(0f, dm.widthPixels.toFloat())
        val endY = (y + dirY * dist).coerceIn(0f, dm.heightPixels.toFloat())
        val path = Path().apply {
            moveTo(x, y)
            lineTo(endX, endY)
        }
        dispatch(GestureDescription.StrokeDescription(path, 0, 300))
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
