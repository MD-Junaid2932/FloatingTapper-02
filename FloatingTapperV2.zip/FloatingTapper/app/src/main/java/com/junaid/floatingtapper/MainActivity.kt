package com.junaid.floatingtapper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = getString(R.string.title)
            textSize = 26f
            setTextColor(Color.BLACK)
        })

        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(status)

        root.addView(Button(this).apply {
            text = getString(R.string.open_accessibility)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        toggle = Button(this).apply {
            setOnClickListener {
                val svc = TapAccessibilityService.instance ?: return@setOnClickListener
                if (svc.isShowing) svc.hideOverlay() else svc.showOverlay()
                refresh()
            }
        }
        root.addView(toggle)

        root.addView(TextView(this).apply {
            text = getString(R.string.instructions)
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(20), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val svc = TapAccessibilityService.instance
        if (svc == null) {
            status.text = getString(R.string.status_off)
            status.setTextColor(0xFFD32F2F.toInt())
            toggle.isEnabled = false
            toggle.text = getString(R.string.show_button)
        } else {
            status.text = getString(R.string.status_on)
            status.setTextColor(0xFF2E7D32.toInt())
            toggle.isEnabled = true
            toggle.text = getString(if (svc.isShowing) R.string.hide_button else R.string.show_button)
        }
    }
}
