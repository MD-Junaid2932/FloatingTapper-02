package com.junaid.floatingtapper

/**
 * Finds a simple arithmetic question (like "4 x 7" or "11 + 8") in OCR text,
 * solves it, and returns the screen position of the option that shows the answer.
 */
object MathSolver {

    data class Line(val text: String, val cx: Float, val cy: Float)

    data class Target(val question: String, val answer: Long, val x: Float, val y: Float)

    private val EXPR = Regex("""(\d+)\s*([+\-−–×xX*÷/])\s*(\d+)""")
    private val INT = Regex("""-?\d+""")

    private fun evaluate(text: String): Pair<String, Long>? {
        for (m in EXPR.findAll(text)) {
            val a = m.groupValues[1].toLongOrNull() ?: continue
            val b = m.groupValues[3].toLongOrNull() ?: continue
            val op = m.groupValues[2]
            val value: Long = when (op) {
                "+" -> a + b
                "-", "−", "–" -> a - b
                "×", "x", "X", "*" -> a * b
                "÷", "/" -> if (b != 0L && a % b == 0L) a / b else continue
                else -> continue
            }
            return Pair("$a $op $b", value)
        }
        return null
    }

    /** Line mode: a short line holding exactly one number, e.g. "28" or "A) 28". */
    private fun lineValue(text: String): Long? {
        val nums = INT.findAll(text).toList()
        if (nums.size != 1) return null
        val rest = text.replace(INT, "").filter { !it.isWhitespace() }
        if (rest.length > 3) return null
        return nums[0].value.toLongOrNull()
    }

    /** Word mode (user marked the options area): a single word that is a number. */
    private fun wordValue(text: String): Long? {
        val t = text.trim { !it.isDigit() && it != '-' }
        return t.toLongOrNull()
    }

    /**
     * @param qLines OCR lines to look for the question in
     * @param qText  all question text joined (fallback when the question is split over lines)
     * @param oItems candidate option items (lines, or single words when [wordMode])
     */
    fun find(qLines: List<Line>, qText: String, oItems: List<Line>, wordMode: Boolean): Target? {
        var qLine: Line? = null
        var q: Pair<String, Long>? = null
        for (l in qLines) {
            val r = evaluate(l.text)
            if (r != null) {
                qLine = l
                q = r
                break
            }
        }
        // Fallback: the question may be split over several OCR lines ("4", "x", "7")
        if (q == null) q = evaluate(qText.replace('\n', ' '))
        val question = q ?: return null

        val questionLine = qLine
        // Only when question and options come from the same OCR pass do we need to
        // exclude the question line and require options to be below it.
        val sameSource = questionLine != null && oItems.any { it === questionLine }
        val qy = if (sameSource) questionLine?.cy else null

        val options = oItems
            .filter { it !== questionLine }
            .mapNotNull { l ->
                val v = if (wordMode) wordValue(l.text) else lineValue(l.text)
                if (v != null) Pair(l, v) else null
            }
        if (options.size < 2) return null

        // If several match, take the lowest one (options sit below the question)
        val best = options
            .filter { it.second == question.second && (qy == null || it.first.cy > qy) }
            .maxByOrNull { it.first.cy } ?: return null

        return Target(question.first, question.second, best.first.cx, best.first.cy)
    }
}
