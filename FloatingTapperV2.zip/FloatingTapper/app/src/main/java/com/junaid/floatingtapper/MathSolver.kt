package com.junaid.floatingtapper

/**
 * Finds a simple arithmetic question (like "4 x 7" or "11 + 8") in OCR text,
 * solves it, and returns the screen position of the option that shows the answer.
 */
object MathSolver {

    data class Line(val text: String, val cx: Float, val cy: Float)

    data class Target(val question: String, val answer: Long, val x: Float, val y: Float)

    private val EXPR = Regex("""(\d+)\s*([+\-−–×xX*÷/])\s*(\d+)""")
    private val INT = Regex("""-?\d+""")

    private fun evaluate(text: String): Pair<String, Long>? {
        for (m in EXPR.findAll(text)) {
            val a = m.groupValues[1].toLongOrNull() ?: continue
            val b = m.groupValues[3].toLongOrNull() ?: continue
            val op = m.groupValues[2]
            val value: Long = when (op) {
                "+" -> a + b
                "-", "−", "–" -> a - b
                "×", "x", "X", "*" -> a * b
                "÷", "/" -> if (b != 0L && a % b == 0L) a / b else continue
                else -> continue
            }
            return Pair("$a $op $b", value)
        }
        return null
    }

    /** An option line is a short line holding exactly one number, e.g. "28" or "A) 28". */
    private fun optionValue(text: String): Long? {
        val nums = INT.findAll(text).toList()
        if (nums.size != 1) return null
        val rest = text.replace(INT, "").filter { !it.isWhitespace() }
        if (rest.length > 3) return null
        return nums[0].value.toLongOrNull()
    }

    fun find(lines: List<Line>, fullText: String): Target? {
        var qLine: Line? = null
        var q: Pair<String, Long>? = null
        for (l in lines) {
            val r = evaluate(l.text)
            if (r != null) {
                qLine = l
                q = r
                break
            }
        }
        // Fallback: the question may be split over several OCR lines ("4", "x", "7")
        if (q == null) q = evaluate(fullText.replace('\n', ' '))
        val question = q ?: return null

        val questionLine = qLine
        val qy = questionLine?.cy
        val options = lines
            .filter { it !== questionLine }
            .mapNotNull { l -> optionValue(l.text)?.let { Pair(l, it) } }
        if (options.size < 2) return null

        // Options sit below the question, so if several lines match take the lowest one
        val best = options
            .filter { it.second == question.second && (qy == null || it.first.cy > qy) }
            .maxByOrNull { it.first.cy } ?: return null

        return Target(question.first, question.second, best.first.cx, best.first.cy)
    }
}
